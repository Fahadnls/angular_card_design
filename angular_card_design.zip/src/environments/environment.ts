export const environment = {
    baseUrl: 'http://192.168.1.109:3000/'
};
